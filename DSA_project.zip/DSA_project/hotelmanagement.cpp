#include <iostream>
using namespace std;

class Hotel {
private:
    struct Node {
        int id, date;
        string name, roomtype;
        Node* next;
    };

    Node* head = NULL;

public:
    void insert();
    void menu();
    void update();
    void search();
    void del();
    void sort();
    void show();
};

void Hotel::menu() {
    int choice;
    while (true) {
        cout << "\n\tWelcome to Hotel Management System Application\n";
        cout << "\n\t____Hotel Management System____";
        cout << "\n\nS.No\tFunction Description";
        cout << "\n1\tAllocate Room\t\t\t(Insert New Room)";
        cout << "\n2\tSearch Room\t\t\t(Search Room by Room ID)";
        cout << "\n3\tUpdate Room\t\t\t(Update Room Record)";
        cout << "\n4\tDelete Room\t\t\t(Delete Room by Room ID)";
        cout << "\n5\tShow Room Records\t\t(Show All Room Records)";
        cout << "\n6\tExit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: insert(); break;
            case 2: search(); break;
            case 3: update(); break;
            case 4: del(); break;
            case 5: sort(); show(); break;
            case 6: exit(0);
            default: cout << "Invalid choice. Please try again.\n";
        }
    }
}

void Hotel::insert() {
    Node* new_node = new Node;
    new_node->next = NULL;

    cout << "\nEnter Room ID: ";
    cin >> new_node->id;

    cin.ignore();
    cout << "Enter Customer Name: ";
    getline(cin, new_node->name);

    cout << "Enter Allocated Date: ";
    cin >> new_node->date;

    cout << "Enter Room Type (single/double/twin): ";
    cin >> new_node->roomtype;

    if (head == NULL) {
        head = new_node;
    } else {
        Node* ptr = head;
        while (ptr->next != NULL) {
            ptr = ptr->next;
        }
        ptr->next = new_node;
    }

    cout << "\nNew Room Inserted Successfully!\n";
}

void Hotel::search() {
    if (head == NULL) {
        cout << "\nNo records to search.\n";
        return;
    }

    int t_id;
    cout << "\nEnter Room ID to search: ";
    cin >> t_id;

    Node* ptr = head;
    while (ptr != NULL) {
        if (t_id == ptr->id) {
            cout << "\nRoom ID: " << ptr->id;
            cout << "\nCustomer Name: " << ptr->name;
            cout << "\nAllocated Date: " << ptr->date;
            cout << "\nRoom Type: " << ptr->roomtype << "\n";
            return;
        }
        ptr = ptr->next;
    }

    cout << "\nRoom not found.\n";
}

void Hotel::update() {
    if (head == NULL) {
        cout << "\nNo records to update.\n";
        return;
    }

    int t_id;
    cout << "\nEnter Room ID to update: ";
    cin >> t_id;

    Node* ptr = head;
    while (ptr != NULL) {
        if (t_id == ptr->id) {
            cout << "Enter New Room ID: ";
            cin >> ptr->id;

            cin.ignore();
            cout << "Enter New Customer Name: ";
            getline(cin, ptr->name);

            cout << "Enter New Allocated Date: ";
            cin >> ptr->date;

            cout << "Enter New Room Type: ";
            cin >> ptr->roomtype;

            cout << "\nRecord Updated Successfully!\n";
            return;
        }
        ptr = ptr->next;
    }

    cout << "\nRoom not found.\n";
}

void Hotel::del() {
    if (head == NULL) {
        cout << "\nNo records to delete.\n";
        return;
    }

    int t_id;
    cout << "\nEnter Room ID to delete: ";
    cin >> t_id;

    if (t_id == head->id) {
        Node* temp = head;
        head = head->next;
        delete temp;
        cout << "Room deleted successfully.\n";
        return;
    }

    Node* ptr = head;
    Node* pre = NULL;
    while (ptr != NULL && ptr->id != t_id) {
        pre = ptr;
        ptr = ptr->next;
    }

    if (ptr == NULL) {
        cout << "\nRoom not found.\n";
    } else {
        pre->next = ptr->next;
        delete ptr;
        cout << "Room deleted successfully.\n";
    }
}

void Hotel::show() {
    if (head == NULL) {
        cout << "\nNo records to show.\n";
        return;
    }

    Node* ptr = head;
    cout << "\nRoom Records:\n";
    while (ptr != NULL) {
        cout << "\nRoom ID: " << ptr->id;
        cout << "\nCustomer Name: " << ptr->name;
        cout << "\nAllocated Date: " << ptr->date;
        cout << "\nRoom Type: " << ptr->roomtype << "\n";
        ptr = ptr->next;
    }
}

void Hotel::sort() {
    if (head == NULL || head->next == NULL)
        return;

    Node* i = head;
    while (i != NULL) {
        Node* j = i->next;
        while (j != NULL) {
            if (i->id > j->id) {
                swap(i->id, j->id);
                swap(i->name, j->name);
                swap(i->date, j->date);
                swap(i->roomtype, j->roomtype);
            }
            j = j->next;
        }
        i = i->next;
    }
}

int main() {
    Hotel h;
    h.menu();
    return 0;
}
